<?php
$Topnavbar ="#ecf0f1";
$websitename="Keerti Computers";
$primarytext="white"; /* This is Footer Text Color */
$footerbutton="#fff";

$footer ="#111";   /*  This Is Footer Background Color */
$footertext ="white";   /*  This Is Footer Text Color */
$secondarybgcolor ="blue";
$secondarytextcolor ="black";

?>