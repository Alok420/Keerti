<?php session_start();?>
<?php include './LoginCheck.php';?> 
<!DOCTYPE html>

<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <?php
        include '../Common/CDN.php';
        include '../Config/ConnectionObjectOriented.php';
        include '../Config/DB.php';
        $db = new DB($conn);
        ?>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </head>
    <body>
        <?php
        $id = $_GET["id"];
        $tb = $_GET["table_name"];
        $column=$_GET["column"];
        $db->showInTable($tb,"$column", array("id" => $id));
        ?>
    </body>
</html>
