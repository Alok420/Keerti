<!DOCTYPE html>
<html>
    <head>
        <Style>
            .script{margin: 1em 0 0.5em 0;
                    color: #343434;
                    font-weight: normal;
                    font-family: 'Ultra', sans-serif;   
                    font-size: 36px;
                    line-height: 42px;
                    text-transform: capitalize;
                    text-align: center;
                    text-shadow: 0 2px white, 0 3px #777;

            }
            .div1{
                width: 100%;
                height: 250px;

            }
            .flex-container {
                display: flex;
                /*background:*/ 
                    flex-wrap: wrap;
                justify-content: center;

            }

            .container{
                margin-top: 10px;
                width: 80%;
                text-align: center;


                box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
            }
        </style>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">

                    <div class="div1">
                        <div class="flex-container" style="">

                            <p class="script"><span>Terms And Condtion</span></p>
                        </div>
                        <div class="flex-container">
                            <div class="container">

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>



    </div>

</div>

</body>
</html>